# procs

This plugin provides completion for [procs](https://github.com/dalance/procs).

To use it, add `procs` to the plugins array in your zshrc file.

```
plugins=(... procs)
```
